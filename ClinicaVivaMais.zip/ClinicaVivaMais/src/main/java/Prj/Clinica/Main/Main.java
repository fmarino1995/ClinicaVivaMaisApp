package Prj.Clinica.Main;

import Prj.Clinica.DbContext.DbContext;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException {

        DbContext con = new DbContext();

        String sql = "INSERT INTO Livro VALUES(2, 'Teste')";
        
        int executaSql = con.executaSql(sql);
        
    }

}
