package Prj.Clinica.DbContext;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DbContext {

    private final String url = "";
    private final String user = "";
    private final String senha = "";
    private Connection con;

    public DbContext() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, senha);

            System.out.println("Conexão Realizada com Sucesso");
        } catch (ClassNotFoundException | SQLException ex) {
        }
    }

    public Connection connectionFactory() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, senha);

            System.out.println("Conexão Realizada com Sucesso");
        } catch (ClassNotFoundException | SQLException ex) {
        }

        return con;
    }

    public int executaSql(String sql) {
        try {
            Statement stm = con.createStatement();
            int res = stm.executeUpdate(sql);
            con.close();
            if (res > 0) {
                System.out.println("Realizado com sucesso");
                return res;
            } else {
                System.out.println("Não foi possivel executar o comando sql");
                return 0;
            }

        } catch (SQLException ex) {
            return 0;
        }
    }

    public ResultSet executaQuery(String sql) {
        try {
            String sql2 = "SELECT * FROM paciente";
            
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            stm.executeQuery("SELECT * FROM consulta;");
            
            return rs;
        }catch(SQLException ex)
        {
            ex.printStackTrace();
        }
            
            return null;
    }

    public ResultSet executaBusca(String sql) {
        try {
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            con.close();
            return rs;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public String buscaCpfLogin(String cpf) {
        String result;
        try {
            String sql = "SELECT cpf FROM paciente WHERE cpf = '" + cpf + "'";
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                result = rs.getString("cpf");
                return result;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
        return null;
    }

    public String obterNomePorCpf(String cpf) {
        try {
            String sql = "SELECT nome FROM paciente WHERE cpf = '" + cpf + "'";
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                String result = rs.getString("nome");
                return result;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
        return null;
    }

    public String[] obterNomeMedicosQuery() {
        String medicos[] = new String[3];
        int i = 0;

        try {
            String sql = "SELECT nome FROM medico;";

            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            while (rs.next()) {
                medicos[i] = rs.getString("nome");
                i++;
            }
            return medicos;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public void obterConsultasQuery(JTable table) {
        String sql = "select m.nome as nome_medico, m.especialidade , c.data_hora, p.nome as nome_paciente from consulta as c inner join medico as m on c.medico_id = m.id inner join paciente as p on c.paciente_id = p.id;";

        try {
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            while (rs.next()) {
                String nome_medico = rs.getString("nome");
                String especialidade = rs.getString("especialidade");
                String data_hora = rs.getTimestamp("data_hora").toString();
                String nome_paciente = rs.getString("nome");

                String tbData[] = {nome_medico, especialidade, data_hora, nome_paciente};

                DefaultTableModel tblModel = (DefaultTableModel) table.getModel();

                tblModel.addRow(tbData);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public boolean verificaHoraQuery(String data_hora) {
        String sql = "SELECT data_hora FROM consulta WHERE data_hora = '" + data_hora + "';";
        try {
            ResultSet rs = this.executaQuery(sql);
            
            return rs.next();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean verificaDataHoraPaciente(String data_hora) {
        String sql = "SELECT nome_paciente FROM consulta WHERE data_hora = '" + data_hora.trim() + "'";
        try {
            ResultSet rs = this.executaQuery(sql);
            
            return rs.next();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public String obterNomePacienteQuery(String cpf) {
        String sql = "SELECT NOME FROM paciente WHERE cpf = '" + cpf + "';";
        
        try{
            ResultSet rs = this.executaQuery(sql);
            
            if(rs.next()) {
                return rs.getString("nome");
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public String obterCpfPacienteQuery(String nomePaciente) {
        String sql = "select cpf from paciente where nome = '" + nomePaciente + "'";
        
        try{
            ResultSet rs = this.executaQuery(sql);
            
            if(rs.next()) {
                return rs.getString("cpf");
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
