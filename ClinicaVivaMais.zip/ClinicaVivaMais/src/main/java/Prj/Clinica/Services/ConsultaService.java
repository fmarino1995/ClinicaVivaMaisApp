package Prj.Clinica.Services;

import Prj.Clinica.DbContext.DbContext;
import Prj.Clinica.Domain.Consulta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ConsultaService {

    private DbContext context;

    public ConsultaService() {

    }

    public List<Consulta> listarConsulta() {
        context = new DbContext();

        String sql = "select c.id, m.nome as nome_medico, m.especialidade , c.data_hora, p.nome as nome_paciente from consulta as c inner join medico as m on c.medico_id = m.id inner join paciente as p on c.paciente_id = p.id;";

        List<Consulta> consultas = new ArrayList<>();

        Connection con = context.connectionFactory();
        Statement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Consulta consulta = new Consulta();

                consulta.setId(rs.getInt("id"));
                consulta.setNomeMedico(rs.getString("nome_medico"));
                consulta.setEspecialidade(rs.getString("especialidade"));
                consulta.setDataHora(rs.getTimestamp("data_hora"));
                consulta.setNomePaciente(rs.getString("nome_paciente"));

                consultas.add(consulta);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return consultas;
    }

    public int retornaMedico(String medico) {

        switch (medico) {
            case "Mario Torres":
                return 1;
            case "Marcia Picolli":
                return 2;
            case "Alberto Paz":
                return 3;
            default:
                System.out.println("Médico não encontrado");
                break;
        }
        return 0;
    }

    public int retornaPaciente(String nomePaciente) {
        String sql = "SELECT id FROM paciente WHERE nome = '" + nomePaciente + "'";

        context = new DbContext();
        ResultSet rs = context.executaQuery(sql);

        try {
            if(rs.next()) {
                return rs.getInt("id");
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return 0;
        }
        return 0;
    }
}
